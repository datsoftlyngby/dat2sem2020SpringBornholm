package persistence;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

public class DB {
 
    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";
    //Local host
    private static final String URL = "jdbc:mysql://localhost:3306/quotes";
    private static final String USER = "root";
    private static final String PASSWORD = "root";
    // DigitalOcean
//    private static final String URL = "jdbc:mysql://104.248.95.162:3306/test";
//    private static final String USER = "tm";
//    private static final String PASSWORD = "Knock_3*";
    private static Connection conn = null;

     // without load from property file
     public static Connection getConnection()  {
        if (conn == null) {            
            try {
                Class.forName(DRIVER); 
                conn = DriverManager.getConnection(URL, USER, PASSWORD);           
            } catch (ClassNotFoundException | SQLException ex) {
                ex.printStackTrace();
            }
        }
        return conn;
    }
      // load from property file
    public static Connection getConnection2()  {
        Connection conn = null;
 
        try (FileInputStream f = new FileInputStream("src/main/java/persistence/db.properties")) {

            // load the properties file
            Properties pros = new Properties();
            pros.load(f);
 
            // assign db parameters
            String url = pros.getProperty("url");
            String user = pros.getProperty("user");
            String password = pros.getProperty("password"); 
            
        
            // create a connection to the database
            if (conn == null) {            
            try {
                Class.forName(DRIVER); //Needed because of servlet call
                conn = DriverManager.getConnection(url, user, password);           
            } catch (ClassNotFoundException | SQLException ex) {
                ex.printStackTrace();
            }
        }
        return conn;

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        return conn;
    }

    public static void main(String[] args) throws ClassNotFoundException {
        System.out.println(" ************ Testing DB class ******************");
        try {
            String sql = "select * from QUOTES";
            ResultSet rs = getConnection().prepareStatement(sql).executeQuery();
            while (rs.next()) {
                System.out.println(rs.getString("quote"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}