package domain;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import persistence.QuoteMapper;

public class Quotes {

    // Til test
    //private ArrayList<String> quotes = new ArrayList();
    private final Random random = new Random();
    private final QuoteMapper qm = new QuoteMapper();

    // Til Test
    public Quotes() {
        //quotes.add("Bedre sent end aldrig");
        //quotes.add("Håbet er lysegrønt");
        //quotes.add("Græsset er altid grønnere hos naboen");
        //quotes.add("Den der ler sidst, ler bedst");
    }

    public String getQuote() {
        List<String> quotes = qm.getQuotes();

        if (quotes != null) {
            return quotes.get(random.nextInt(quotes.size()));
        } else {
            return "Ingen citat i dag";
        }
    }
}
