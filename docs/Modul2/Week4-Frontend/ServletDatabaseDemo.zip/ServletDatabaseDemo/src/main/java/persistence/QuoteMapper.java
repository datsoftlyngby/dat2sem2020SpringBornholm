package persistence;

import static persistence.DB.getConnection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class QuoteMapper {

    public List<String> getQuotes() {
        List<String> quotes = new ArrayList();
        String sql = "select * from QUOTES";
        ResultSet rs = null;
        try {
            rs = getConnection().prepareStatement(sql).executeQuery();
        } catch (SQLException ex) {
        }

        try {
            while (rs.next()) {
                String quote = rs.getString("quote");
                quotes.add(quote);
            }
        } catch (SQLException ex) {
            Logger.getLogger(QuoteMapper.class.getName()).log(Level.SEVERE, null, ex);
        }
        return quotes;
    }

    public static void main(String[] args) {
        System.out.println(" ************ Testing QuoteMapper class ******************");
        QuoteMapper qm = new QuoteMapper();
        try {
            for (String quote : qm.getQuotes()) {
                System.out.println(quote);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

}
