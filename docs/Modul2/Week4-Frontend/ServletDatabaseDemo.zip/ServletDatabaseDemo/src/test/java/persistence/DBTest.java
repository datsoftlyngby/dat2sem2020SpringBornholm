package persistence;

import java.sql.Connection;
import org.junit.Test;
import static org.junit.Assert.*;

public class DBTest {

    @Test
    public void testGetConnection() {
        Connection result = DB.getConnection();
        assertNotNull(result);
    }

    @Test
    public void testGetConnection2() {
        Connection result = DB.getConnection2();
        assertNotNull(result);
    }

}
