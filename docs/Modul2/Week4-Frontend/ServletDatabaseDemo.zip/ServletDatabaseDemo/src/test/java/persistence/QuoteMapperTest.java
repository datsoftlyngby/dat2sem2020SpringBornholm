package persistence;

import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;

public class QuoteMapperTest {
    
    @Test
    public void testGetQuotes() {
        QuoteMapper instance = new QuoteMapper();
        int expectedNumberOfQuotes = 4;
        List<String> result = instance.getQuotes();
        assertEquals(expectedNumberOfQuotes, result.size());
    }
}
