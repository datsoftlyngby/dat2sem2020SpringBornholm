package domain;

import java.util.ArrayList;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;

public class QuotesTest {

    ArrayList<String> testData = new ArrayList();
    Quotes classUnderTest = new Quotes();

    @Before
    public void setup() {
        testData.add("Bedre sent end aldrig");
        testData.add("Håbet er lysegrønt");
        testData.add("Græsset er altid grønnere hos naboen");
        testData.add("Den der ler sidst, ler bedst");
    }

    @Test
    public void testGetQuoteVersion1() {
        String result;
        for (int i = 0; i < 100; i++) {
            result = classUnderTest.getQuote();
            assertTrue(testData.contains(result));
        }
    }

    @Test
    public void testGetQuoteVersion2() {
        final int ANTAL_LOOPS = 100;        
        int[] testResults = new int[testData.size()];
        
        String result;
        int indexPosition;
        
        for (int i = 0; i < ANTAL_LOOPS; i++) {
            result = classUnderTest.getQuote();
            indexPosition = testData.indexOf(result);
            testResults[indexPosition]++;
        }
        
        //Check fordeling af test værdier
        for (int i = 0; i < testResults.length; i++) {
            System.out.println("Quote fordeling " + testResults[i]);
            assertTrue(new Double(testResults[i]) / ANTAL_LOOPS * 100 > 15);
            assertTrue(new Double(testResults[i]) / ANTAL_LOOPS * 100 < 80);
        }
    }
}
