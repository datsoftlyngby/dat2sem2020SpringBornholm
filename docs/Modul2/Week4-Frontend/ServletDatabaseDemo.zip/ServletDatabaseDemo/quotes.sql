DROP TABLE if exists QUOTES;
CREATE TABLE QUOTES (	
	QUOTE VARCHAR(60) primary key not null
); 


insert into QUOTES values ('Bedre sent end aldrig');
insert into QUOTES values ('Håbet er lysegrønt');
insert into QUOTES values ('Græsset er altid grønnere hos naboen');
insert into QUOTES values ('Den der ler sidst, ler bedst');
insert into QUOTES values ('Lev stærkt dø ung');
commit;