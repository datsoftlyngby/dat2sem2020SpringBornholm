package domain;

import java.io.Serializable;

public class Book implements Serializable {
    private final int id;
    private final String title;
    private final String author;
    private double price;
    private int qty;
    private static int count = 1;

    public Book(String title, String author, double price, int qty) {
        this.id = count++;
        this.title = title;
        this.author = author;
        this.price = price;
        this.qty = qty;        
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }
    
    public String getAuthor() {
        return author;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    @Override
    public String toString() {
        return "Book{" + "title=" + title + ", author=" + author + ", price=" + price + ", id=" + id + '}';
    }
    
    
}
