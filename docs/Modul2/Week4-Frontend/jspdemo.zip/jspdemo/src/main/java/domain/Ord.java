package domain;

public class Ord  {
    private String tekst;

    public Ord(String tekst) {
        this.tekst = tekst;
    }
    
    public String getTekst() {
        return tekst;
    }

    public void setTekst(String tekst) {
        this.tekst = tekst;
    }
    
    
}
