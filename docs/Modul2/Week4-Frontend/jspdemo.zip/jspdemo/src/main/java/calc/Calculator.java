package calc;

public class Calculator {
    public static int sum(int i, int j){      
        if (i < 0 || j < 0) {
            throw new IllegalArgumentException();
        }
        return i + j;
    }
}
