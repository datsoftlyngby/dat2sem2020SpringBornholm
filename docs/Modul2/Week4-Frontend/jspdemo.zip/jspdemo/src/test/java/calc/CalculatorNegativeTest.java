package calc;

import java.util.Arrays;
import java.util.Collection;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

@RunWith(Parameterized.class)
public class CalculatorNegativeTest {

    private final int value1, value2;
    
    @Parameterized.Parameters
    public static Collection getTestParameters() {
        return Arrays.asList(new Object[][]{
            {-2, 1}, {1, -1}, { -1, -1}});
     }

    //constructor uses @Parameters
    public CalculatorNegativeTest(int n1, int n2) {      
        value1 = n1;
        value2 = n2;       
    }    
    
    @Test (expected=IllegalArgumentException.class)
    public void testSum() {
        Calculator.sum(value1, value2);
    }
   
}
